"""
0_Directed_Init.py
------------------
SETIA演化之前运行，生成定向搜索的初始AM文件。
不依赖先前的SETIA结果，所有参数直接从输入数据计算。

用法：
    # 第一次运行（无先验结果）
    python 0_Directed_Init.py \
        -r data/setia_input_linear_CPM_pseudocount.tsv \
        -c data/BMMC_TF_DNA_matrix.txt \
        -t data/BMMC_promoter_strength.txt \
        -l data/BMMC_gene_length.txt \
        -o data/BMMC_init_AMs \
        -n 4

    # 有先验结果时，加 -prev 让已收敛的基因保留SETIA结果
    python 0_Directed_Init.py \
        -r data/setia_input_linear_CPM_pseudocount.tsv \
        -c data/BMMC_TF_DNA_matrix.txt \
        -t data/BMMC_promoter_strength.txt \
        -l data/BMMC_gene_length.txt \
        -o data/BMMC_init_AMs \
        -n 4 \
        -prev result/BMMC_6 \
        --threshold 0.15

输出：
    data/BMMC_init_AMs/AM_0.txt ~ AM_3.txt
    每个文件一行3136字符的AM字符串，直接通过 -d 参数传给SETIA
"""
import sys, os, getopt, warnings, math
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + '/helper')
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + '/dynamics_module')
from dynamics import get_param_by_TPM
from utility_functions import GetRegulatorForGene

# ===== 参数解析 =====
opts, _ = getopt.getopt(sys.argv[1:], 'r:c:t:l:o:n:p:',
                         ['input_RNAseq=', 'input_ChIP=', 'promoter_strengths=',
                          'gene_length=', 'output_dir=', 'n_seeds=',
                          'prev_result=', 'threshold=',
                          'mRNA_elongation_rate=', 'beam_width=', 'tolerance='])

sys_rnaseq = ''; sys_chip = ''; sys_promoter = ''; sys_genelen = ''
sys_outdir = ''; n_seeds = 4; sys_prev = ''; threshold = 0.15
mRNA_elongation_rate = 4.8; beam_width = 5; tolerance = 0.15

for opt, arg in opts:
    if   opt in ('-r', '--input_RNAseq'):          sys_rnaseq  = arg
    elif opt in ('-c', '--input_ChIP'):             sys_chip    = arg
    elif opt in ('-t', '--promoter_strengths'):     sys_promoter= arg
    elif opt in ('-l', '--gene_length'):            sys_genelen = arg
    elif opt in ('-o', '--output_dir'):             sys_outdir  = arg
    elif opt in ('-n', '--n_seeds'):                n_seeds     = int(arg)
    elif opt in ('-p', '--prev_result'):            sys_prev    = arg
    elif opt in ('--threshold',):                   threshold   = float(arg)
    elif opt in ('--mRNA_elongation_rate',):        mRNA_elongation_rate = float(arg)
    elif opt in ('--beam_width',):                  beam_width  = int(arg)
    elif opt in ('--tolerance',):                   tolerance   = float(arg)

os.makedirs(sys_outdir, exist_ok=True)
base_dir = os.path.dirname(os.path.abspath(sys_rnaseq))

# ===== 读数据 =====
pseudo    = np.loadtxt(sys_rnaseq, delimiter='\t')[:, 1:]
genes     = open(os.path.join(base_dir, 'BMMC_gene_list.txt')).readline().split()
chip      = np.loadtxt(sys_chip, dtype=int)
promoter  = np.loadtxt(sys_promoter, delimiter='\t')
gene_length = np.loadtxt(sys_genelen, delimiter='\t', dtype=int)
n_genes   = len(genes)
n_conds   = pseudo.shape[0]
gene_max  = pseudo.max(axis=0)
gene_min  = pseudo.min(axis=0)
indexes_diff = [i for i in range(n_genes) if gene_max[i] != gene_min[i]]
k = 30

# ===== 参数计算：直接从原始数据，不依赖GRN_components =====
def compute_params(gi):
    """计算基因gi的ODE参数，和SETIA的ParametersInitiations完全一致"""
    TR      = promoter[0, gi] * 60 * mRNA_elongation_rate / gene_length[gi]
    Leakage = TR * gene_min[gi] / gene_max[gi]
    deg     = TR / gene_max[gi]
    expr_levels = np.array(sorted(set(pseudo[:, gi])))
    expr_levels = expr_levels[~np.isnan(expr_levels)]
    _, f0_c = get_param_by_TPM(expr_levels)
    return f0_c[0], f0_c[2], f0_c[4], Leakage, deg, TR  # f0, c2, c4, L, deg, TR

# ===== Hill函数 =====
def split_and_average(lst):
    lst = list(lst)
    if len(lst) == 1: return [lst[0], lst[0]]
    if len(lst) == 2: return [lst[0], lst[1]]
    g = np.array_split(lst, 3); g1, g2, g3 = [list(x) for x in g]
    return [(max(g1)+min(g2))/2, (max(g2)+min(g3))/2]

t1_cache = {gi: split_and_average(sorted(np.array(sorted(set(pseudo[:,gi])))))[0]
            for gi in indexes_diff}

def hill(X, gi_reg):
    t1 = t1_cache[gi_reg]
    if t1 <= 0 or X <= 0: return 0.0
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        r = X / t1; return r**k / (r**k + 1)

def analytic_fitness(gi_t, acts, reps):
    f0, c2, c4, L, deg, TR = compute_params(gi_t)
    tgt = pseudo[:, gi_t]; gmax = tgt.max(); gmin = tgt.min()
    total = 0
    for cond in range(n_conds):
        HA = sum(hill(pseudo[cond,i],i) for i in acts) / (1+c2)
        HR = sum(hill(pseudo[cond,i],i) for i in reps) / (1+c4)
        reg = f0 + (1-f0)*HA - HR*f0
        ss  = (L + (TR-L)*reg) / deg
        total += abs(ss - tgt[cond]) / (gmax - gmin)
    return total / n_conds

# ===== Beam Search =====
def beam_search(gi_t):
    f0, c2, c4, L, deg, TR = compute_params(gi_t)
    tgt = pseudo[:, gi_t]; null_ss = (L + (TR-L)*f0) / deg
    allowed  = [i for i in indexes_diff if chip[i, gi_t]==1 and i!=gi_t]
    need_rep = [c for c in range(n_conds) if tgt[c] < null_ss]
    need_act = [c for c in range(n_conds) if tgt[c] > null_ss]

    if need_rep and need_act:
        rep_pool = [i for i in allowed
                    if np.mean([hill(pseudo[c,i],i) for c in need_rep]) >
                       np.mean([hill(pseudo[c,i],i) for c in need_act])]
        act_pool = [i for i in allowed
                    if np.mean([hill(pseudo[c,i],i) for c in need_act]) >
                       np.mean([hill(pseudo[c,i],i) for c in need_rep])]
    elif need_rep:
        rep_pool = allowed; act_pool = []
    else:
        rep_pool = []; act_pool = allowed

    def expand(beams, pool, mode):
        """一轮扩展：对每个beam，试加pool里的每个TF"""
        candidates = []
        for reps, acts, cur_fit in beams:
            current = reps if mode=='rep' else acts
            for tf in pool:
                if tf in current: continue
                new_reps = reps + [tf] if mode=='rep' else reps
                new_acts = acts + [tf] if mode=='act' else acts
                f = analytic_fitness(gi_t, new_acts, new_reps)
                if f < cur_fit:
                    candidates.append((new_reps, new_acts, f))
        if not candidates:
            return beams  # 没有改善，返回原beam
        seen = set(); unique = []
        for reps, acts, f in candidates:
            key = (frozenset(reps), frozenset(acts))
            if key not in seen:
                seen.add(key); unique.append((reps, acts, f))
        unique.sort(key=lambda x: x[2])
        best = unique[0][2]
        return [(r,a,f) for r,a,f in unique if f <= best+tolerance][:beam_width]

    beams = [([], [], analytic_fitness(gi_t, [], []))]
    for _ in range(4): beams = expand(beams, rep_pool, 'rep')
    for _ in range(2): beams = expand(beams, act_pool, 'act')

    # 去重，按fitness排序
    seen = set(); result = []
    for reps, acts, f in sorted(beams, key=lambda x: x[2]):
        key = (frozenset(reps), frozenset(acts))
        if key not in seen:
            seen.add(key); result.append((reps, acts, f))
    return result

# ===== 读上一轮SETIA结果（可选）=====
has_prev   = bool(sys_prev)
prev_fit   = {}   # col -> fitness
prev_AM    = [['0']*n_genes for _ in range(n_genes)]  # 默认全零

if has_prev:
    rf = np.loadtxt(sys_prev + '_ResultFlow.txt')
    for col in range(len(indexes_diff)):
        prev_fit[col] = rf[-1, col]
    for line in open(sys_prev + '_GRN_components.txt').readlines()[1:]:
        parts = line.strip().split('\t')
        target = int(parts[0]); config = parts[1]
        for reg, val in enumerate(config):
            prev_AM[reg][target] = val
    print(f"已读取上一轮结果：{sys_prev}")
    print(f"对fitness > {threshold} 的基因做定向搜索，其余保留SETIA结果")
else:
    print("无先验结果，所有基因都做定向搜索")

print()

# ===== 对需要搜索的基因做beam search =====
gene_candidates = {}  # gi -> [(reps, acts, fit), ...]

print(f"{'基因':<10} {'当前fitness':>12}  {'候选数':>8}  {'最优beam':>10}")
print("-"*50)

for col, gi in enumerate(indexes_diff):
    current_fit = prev_fit.get(col, 1e6)  # 无先验时设为无穷大，全部搜索
    null_fit    = analytic_fitness(gi, [], [])

    # 决定是否需要搜索
    if has_prev and current_fit <= threshold:
        continue  # 已收敛，保留SETIA结果

    candidates = beam_search(gi)
    # 只保留比当前更好的候选（无先验时current_fit=1e6，所有候选都会入选）
    candidates = [(r,a,f) for r,a,f in candidates if f < current_fit - 0.01]

    if candidates:
        gene_candidates[gi] = candidates
        print(f"{genes[gi]:<10} {current_fit:>12.4f}  {len(candidates):>8}  {candidates[0][2]:>10.4f}")
    else:
        print(f"{genes[gi]:<10} {current_fit:>12.4f}  {'无改善':>8}")

print()

# ===== 生成n_seeds个AM文件 =====
print(f"生成{n_seeds}个初始AM文件...")
for seed_idx in range(n_seeds):
    AM = [row[:] for row in prev_AM]  # 从上一轮结果出发（或全零）

    for gi, candidates in gene_candidates.items():
        reps, acts, fit = candidates[seed_idx % len(candidates)]
        for reg in range(n_genes): AM[reg][gi] = '0'
        for rep in reps: AM[rep][gi] = '2'
        for act in acts: AM[act][gi] = '1'

    am_string = ''.join(''.join(row) for row in AM)
    outpath   = os.path.join(sys_outdir, f'AM_{seed_idx}.txt')
    with open(outpath, 'w') as fout:
        fout.write(am_string)
    n_edges = am_string.count('1') + am_string.count('2')
    print(f"  AM_{seed_idx}.txt  (非零边={n_edges})")

print(f"\n完成。输出目录：{sys_outdir}")
print(f"在2_GRN_inference.sh里加上：")
print(f"    -d {sys_outdir}/AM_${{RELATIVE_IDX}}.txt")
