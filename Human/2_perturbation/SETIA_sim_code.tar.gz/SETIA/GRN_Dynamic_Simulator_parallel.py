import os, sys, re
import multiprocessing
import path_setup
import pandas as pd
import numpy as np
from matplotlib import pyplot as plt
import random
import math
import copy
from scipy.integrate import solve_ivp
from distance_functions import *
from mutation_functions import *
from dynamics import *
from utility_functions import *
from population_functions import *
from GRN_Expanded_Combinatorial_2025 import GRN
from Combine_Redundant_Attractors import *
import sympy as sp
import getopt
from pathlib import Path


# ─────────────────────────────────────────────────────────────────────────────
# Worker function (must be at module scope for multiprocessing)
# ─────────────────────────────────────────────────────────────────────────────
def run_one_sample(args):
    (Global_i, wttp_i, overexpression_i, grn_pickle,
     indexes_of_diff_gene, Diff_gene_cannot_be_inferred,
     TrainingCount, sys_PerturbationPower,
     Num_of_genes_diff_TPM, TranscriptionPofileMax, TranscriptionPofileMin) = args

    import copy as _copy, random as _random
    import numpy as _np
    import sympy as _sp
    from scipy.integrate import solve_ivp as _solve_ivp

    this_grn = _copy.deepcopy(grn_pickle)

    NewmRNA = _np.array([0.0] * len(wttp_i[1]))
    for j in range(len(NewmRNA)):
        v = wttp_i[1][j]
        NewmRNA[j] = (v if not (_np.isnan(v) if isinstance(v, float) else False)
                      else 0.0) * (1 + _random.choice([1, -1]) * sys_PerturbationPower)

    this_grn.SetmRNA(NewmRNA, wttp_i[0], overexpression_i)

    scipystring = this_grn.Delta_mRNA_Network(
        wttp_i[0], overexpression_i,
        indexes_of_diff_gene, this_grn.mRNA, Diff_gene_cannot_be_inferred)

    _ns = {}
    exec(compile(scipystring, "<string>", "exec"), globals(), _ns)
    update_fn = _ns['update_mRNA_protein']

    # Project the state onto the non-negative orthant on every RHS evaluation.
    # Radau (and its internal finite-difference Jacobian) can probe y slightly
    # below zero, where the Hill terms y**Sigmoid_k (non-integer exponent) evaluate
    # to NaN in NumPy and abort the LU factorization. Gene expression is physically
    # non-negative and a negative regulator contributes zero activation, so this is
    # the correct Hill behaviour and a no-op for the non-negative trajectories of
    # converging runs.
    _update_fn_raw = update_fn

    def update_fn(t, y, knockoutlist):
        out = _update_fn_raw(t, _np.maximum(_np.asarray(y, dtype=float), 0.0),
                             knockoutlist)
        # Safety net: a Hill base can itself be a (possibly negative) linear
        # combination of regulators, so an occasional term may still evaluate to
        # NaN/inf even after y is clamped. Replace any non-finite derivative with 0
        # so Radau's LU step never receives a non-finite Jacobian. This is a no-op
        # whenever the RHS is already finite (i.e. every converging run).
        return _np.nan_to_num(_np.asarray(out, dtype=float),
                              nan=0.0, posinf=0.0, neginf=0.0)

    transformed_KO_list = [i_ for i_, val in enumerate(indexes_of_diff_gene)
                           if val in wttp_i[0]]

    sol = _solve_ivp(update_fn,
                     [0, TrainingCount],
                     list(this_grn.mRNA[indexes_of_diff_gene]),
                     args=(wttp_i[0],),
                     t_eval=[int(TrainingCount / 250) * tick for tick in range(0, 251)],
                     method='Radau')
    npmRNA_continuous = sol.y.T

    y = _sp.symbols('y1:%d' % (Num_of_genes_diff_TPM + 1))
    # Clamp to non-negative before evaluating the Jacobian: Radau can overshoot a
    # few genes slightly below zero, and the Hill terms use a non-integer exponent
    # (Sigmoid_k), so a negative base raised to that power yields a complex number
    # that float() cannot convert. Gene expression is physically non-negative and
    # the RHS already floors it (if y<=0: outlist=-y), so clamping here is faithful
    # and is a no-op for the all-non-negative attractors of converging runs.
    point = {y[k]: max(0.0, float(npmRNA_continuous[-1][k])) for k in range(Num_of_genes_diff_TPM)}
    Jacobian_matrix = [[] for _ in range(Num_of_genes_diff_TPM)]
    Derivative_values = []
    _jac_ns = {**globals(), 'y': y, **{str(y[k]): y[k] for k in range(len(y))}}
    for eq_i, eq_line in enumerate(scipystring.split('\n')):
        eq_str = eq_line.replace(' ', '')
        if eq_str[:11] == 'delta_mRNA[':
            exec('eq_of_string = {}'.format(eq_str.split('=')[1]), _jac_ns)
            eq_sym = _jac_ns['eq_of_string']

            def _safe_eval(expr):
                # A Hill base can be a linear combination of regulators that is
                # negative even when every gene value is non-negative; raising it to
                # the non-integer Sigmoid_k then yields a complex sympy number that
                # float() rejects. Take the real part (the physically meaningful
                # value) and replace any non-finite result with 0.
                val = expr.subs(point)
                try:
                    fval = float(val)
                except TypeError:
                    fval = float(_sp.re(val))
                return fval if _np.isfinite(fval) else 0.0

            Derivative_values.append(_safe_eval(eq_sym))
            for var_j in range(len(y)):
                _jac_ns['df{}_dy{}_at_point'.format(eq_i - 3, var_j)] = \
                    _safe_eval(_sp.diff(eq_sym, y[var_j]))
    row_idx = 0
    for eq_i, eq_line in enumerate(scipystring.split('\n')):
        eq_str = eq_line.replace(' ', '')
        if eq_str[:11] == 'delta_mRNA[':
            for var_j in range(Num_of_genes_diff_TPM):
                Jacobian_matrix[row_idx].append(
                    _jac_ns.get('df{}_dy{}_at_point'.format(eq_i - 3, var_j), 0.0))
            row_idx += 1

    eigenvalues = _np.linalg.eigvals(Jacobian_matrix)
    Derivative_values = [abs(x) for x in Derivative_values]
    Derivative_values = [v for idx, v in enumerate(Derivative_values)
                         if idx not in transformed_KO_list]

    IsPointAttractor = (max(eigenvalues.real) <= 0 and
                        max(Derivative_values) < max(0.5, 0.01 * float(_np.max(npmRNA_continuous[-1]))))

    Attractor_distance = float(_np.round(
        (1 / len(indexes_of_diff_gene)) * GetAttractorDistance(
            this_grn.mRNA[indexes_of_diff_gene], npmRNA_continuous[-1],
            _np.array(TranscriptionPofileMax)[indexes_of_diff_gene],
            _np.array(TranscriptionPofileMin)[indexes_of_diff_gene]), 5))

    print(f'Sample {Global_i} | IsPointAttractor: {IsPointAttractor} | Distance: {Attractor_distance}', flush=True)
    return (Global_i,
            list(_np.round(this_grn.mRNA[indexes_of_diff_gene], 1)),
            list(_np.round(npmRNA_continuous[-1], 1)),
            IsPointAttractor,
            Attractor_distance)


def read_refinement_files(dir_path='./result'):
    p = Path(dir_path)
    files = sorted(p.glob('Refinement_for_gene_*.txt'))
    out = {}
    for f in files:
        try:
            text = f.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            text = f.read_text(encoding='latin1')
        m = re.match(r'Refinement_for_gene_(.+)\.txt$', f.name)
        key = m.group(1) if m else f.stem
        out[key] = text
    return out


def load_fitness(fitness_path, fitness_threshold=0.10):
    """Load Preliminary_training_result.txt and return set of gene indices with fitness > threshold."""
    bad_genes = set()
    try:
        with open(fitness_path) as f:
            for line in f:
                parts = line.strip().split('\t')
                if len(parts) == 2:
                    g_idx = int(parts[0])
                    fit   = float(parts[1])
                    if fit > fitness_threshold:
                        bad_genes.add(g_idx)
        print(f'Fitness filter: {len(bad_genes)} genes excluded (fitness > {fitness_threshold}): {sorted(bad_genes)}')
    except FileNotFoundError:
        print(f'Warning: fitness file not found at {fitness_path}, no genes excluded.')
    return bad_genes


def load_wttp(rna_path):
    """Load RNAseq input file into WTTP dict."""
    raw = np.array(pd.read_csv(rna_path, header=None, delimiter='\t', dtype=str))
    wttp = {}
    for i in range(raw.shape[0]):
        if raw[i][0] == '-1':
            wttp[str(i)] = [[], np.array(raw[i][1:], dtype=float)]
        elif len(raw[i][0]) == 1:
            wttp[str(i)] = [[int(raw[i][0])], np.array(raw[i][1:], dtype=float)]
        else:
            wttp[str(i)] = [np.array(raw[i][0].split(','), dtype=int).tolist(),
                            np.array(raw[i][1:], dtype=float)]
    return wttp


def apply_cli_perturbation(wttp, cli_ko, cli_oe):
    """Apply CLI KO/OE to all rows of wttp (in-place)."""
    if not cli_ko and not cli_oe:
        return
    all_keys = list(wttp.keys())
    all_stack = np.array([wttp[k][1] for k in wttp], dtype=float)
    oe_max = np.nanmax(all_stack, axis=0)
    pert_codes = list(cli_ko) + [-(g + 2) for g in cli_oe]
    print(f'CLI perturbation applied to ALL {len(all_keys)} row(s): KO={cli_ko}, OE={cli_oe}')
    for k in all_keys:
        wttp[k][0] = pert_codes[:]
        for g in cli_oe:
            wttp[k][1][g] = oe_max[g]


def build_stats(wttp, total_genes, base_wttp=None):
    """Build BaseMatrixCollector, Overexpression, Knockout, profile stats.
    base_wttp: original wttp before perturbation, used to compute indexes_of_diff_gene.
               If None, uses wttp (backward compatible for WT case).
    """
    Overexpression = np.zeros((len(wttp), total_genes))
    Knockout = np.zeros((len(wttp), total_genes))
    BaseMatrixCollector = []

    # Use original (pre-perturbation) data to compute diff/same gene indices
    ref = base_wttp if base_wttp is not None else wttp
    OriginalCollector = np.array([ref[k][1].copy() for k in ref])
    OrigMax = np.nanmax(OriginalCollector, axis=0)
    OrigMin = np.nanmin(OriginalCollector, axis=0)

    indexes_of_diff_gene, indexes_of_same_gene = [], []
    for x in range(total_genes):
        if (np.isnan(OrigMax[x]) or np.isnan(OrigMin[x]) or OrigMax[x] == OrigMin[x]):
            indexes_of_same_gene.append(x)
        else:
            indexes_of_diff_gene.append(x)

    TranscriptionPofileMax = list(OrigMax)
    TranscriptionPofileMin = list(OrigMin)
    TranscriptionPofileAve = [0.5 * (OrigMax[x] + OrigMin[x]) for x in range(total_genes)]

    for keys in wttp:
        for each in wttp[keys][0]:
            if each >= 0:
                Knockout[int(keys)][each] = wttp[keys][1][each]
                wttp[keys][1][each] = np.nan
            elif each <= -2:
                Overexpression[int(keys)][-each - 2] = wttp[keys][1][-each - 2]
                wttp[keys][1][-each - 2] = np.nan
        BaseMatrixCollector.append(wttp[keys][1])

    BaseMatrixCollector = np.array(BaseMatrixCollector)

    return (Overexpression, Knockout, BaseMatrixCollector,
            TranscriptionPofileMax, TranscriptionPofileMin, TranscriptionPofileAve,
            indexes_of_diff_gene, indexes_of_same_gene)


def build_grn(test_grn, indexes_of_same_gene, sys_random_test, total_genes):
    """Build and return GRN object."""
    if sys_random_test:
        rand_str = ''.join(str(x) for x in np.random.randint(2, size=total_genes ** 2))
        Configuration = String012ToMatrix(rand_str)
        LogicGates = LogicGatesString2Matrix_Expanded(
            ','.join([','.join(map(str, range(total_genes)))] * total_genes))
    else:
        Configuration = String012ToMatrix(test_grn['Adjacency Matrix:'][0])
        LogicGates = LogicGatesString2Matrix_Expanded(test_grn['Logic Gate:'][0])

    for g in indexes_of_same_gene:
        Configuration[0][g, :] = 0
        Configuration[1][g, :] = 0
        Configuration[0][:, g] = 0
        Configuration[1][:, g] = 0

    f0_c = eval(test_grn['f0:'][0])
    Sigmoid_ks = eval(test_grn['Hill Coefficient:'][0])
    TranscriptionThreshold = eval(test_grn['TF Effective Threshold:'][0])
    DegradationRatemRNA = eval(test_grn['mRNA Degradation Rate:'][0])
    Leakages = eval(test_grn['Leakage Rate:'][0])
    TranscriptionRate = eval(test_grn['Transcription Rate:'][0])

    return GRN('this_GRN', [], Configuration, 0,
               TranscriptionRate, DegradationRatemRNA,
               TranscriptionThreshold, LogicGates,
               Sigmoid_ks, Leakages, f0_c)


def run_simulation(wttp, overexpression, this_grn, indexes_of_diff_gene,
                   training_count, perturbation_power,
                   transcription_max, transcription_min, output_name,
                   n_workers=None):
    """Run parallel simulation and save results."""
    Diff_gene_cannot_be_inferred = []
    Num_of_genes_diff_TPM = len(indexes_of_diff_gene)

    args_list = [
        (Global_i,
         wttp[str(Global_i)],
         overexpression[Global_i],
         copy.deepcopy(this_grn),
         indexes_of_diff_gene,
         Diff_gene_cannot_be_inferred,
         training_count,
         perturbation_power,
         Num_of_genes_diff_TPM,
         transcription_max,
         transcription_min)
        for Global_i in range(len(wttp))
    ]

    if n_workers is None:
        n_workers = max(1, multiprocessing.cpu_count() - 1)
    print(f'Running {len(wttp)} samples on {n_workers} workers...')

    with multiprocessing.Pool(processes=n_workers) as pool:
        results = pool.map(run_one_sample, args_list)
    results.sort(key=lambda x: x[0])

    Path('./result').mkdir(exist_ok=True)
    outpath = f'./result/GRN_dynamic_local_search_result_{output_name}.txt'
    GRN_Performance = []
    with open(outpath, 'a') as outfile:
        outfile.write('indexes_of_diff_gene\t' + '\t'.join(map(str, indexes_of_diff_gene)) + '\n')
        for (Global_i, initial_state, final_state, IsPointAttractor, Attractor_distance) in results:
            outfile.write(f'transcriptional profile #{Global_i}\n')
            outfile.write('initial state\t' + '\t'.join(map(str, initial_state)) + '\n')
            outfile.write('final state\t' + '\t'.join(map(str, final_state)) + '\n')
            outfile.write('is point attractor\t' + str(IsPointAttractor) + '\n')
            outfile.write('attractor distance\t' + str(Attractor_distance) + '\n')
            GRN_Performance.append(Attractor_distance)
        overall = np.nanmean(GRN_Performance)
        outfile.write(f'overall performance\t{overall}\t{sum(GRN_Performance)}\n')

    print(f'Saved to {outpath}')
    print(f'Overall performance: {overall:.4f}')
    return results


# ─────────────────────────────────────────────────────────────────────────────
# Batch run: WT + random + all single KO + all single OE
# ─────────────────────────────────────────────────────────────────────────────
def run_batch(grn_path, input_path, genelen_path, promoter_path,
              n, total_genes, prefix='Sc_m0', skip_existing=True,
              random_seed=42, perturbation_power=0.0, n_workers=None):

    random.seed(random_seed)
    np.random.seed(random_seed)

    # Load static data
    gene_length = np.array(pd.read_csv(genelen_path, header=None, delimiter='\t'), dtype=int)[0]
    TotalNumberOfGenes = len(gene_length)

    test_grn = {}
    with open(grn_path) as f:
        for line in f:
            parts = line.strip().split('\t')
            if parts:
                test_grn[parts[0]] = parts[1:]

    # Build conditions: (output_name, random_mode, cli_ko, cli_oe)
    conditions = [(f'{prefix}_WT', 0, [], [])]
    conditions.append((f'{prefix}_random', 1, [], []))
    for i in range(total_genes):
        conditions.append((f'{prefix}_KO{i}', 0, [i], []))
    for i in range(total_genes):
        conditions.append((f'{prefix}_OE{i}', 0, [], [i]))

    print(f'Total conditions: {len(conditions)} (1 WT + 1 random + {total_genes} KO + {total_genes} OE)')

    for ci, (name, mode, cli_ko, cli_oe) in enumerate(conditions):
        outpath = Path(f'./result/GRN_dynamic_local_search_result_{name}.txt')
        if skip_existing and outpath.exists():
            print(f'[{ci+1:3d}/{len(conditions)}] [SKIP] {name}')
            continue
        print(f'[{ci+1:3d}/{len(conditions)}] [RUN]  {name}  (m={mode}, KO={cli_ko}, OE={cli_oe})')

        # Load fresh WTTP for each condition
        wttp = load_wttp(input_path)
        base_wttp = {k: [v[0][:], v[1].copy()] for k, v in wttp.items()}  # snapshot before perturbation
        apply_cli_perturbation(wttp, cli_ko, cli_oe)

        (Overexpression, Knockout, BaseMatrixCollector,
         TranscriptionPofileMax, TranscriptionPofileMin, TranscriptionPofileAve,
         indexes_of_diff_gene, indexes_of_same_gene) = build_stats(wttp, TotalNumberOfGenes, base_wttp=base_wttp)

        this_grn = build_grn(test_grn, indexes_of_same_gene, mode, TotalNumberOfGenes)

        run_simulation(wttp, Overexpression, this_grn,
                       indexes_of_diff_gene, int(n), perturbation_power,
                       TranscriptionPofileMax, TranscriptionPofileMin,
                       name, n_workers=n_workers)

    print('\n=== Batch complete ===')


# ─────────────────────────────────────────────────────────────────────────────
# CLI entry point (single condition)
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    sys_path = os.getcwd()
    sys_input_RNAseq = ""
    sys_promoter_strengths = ""
    sys_gene_length = []
    sys_PerturbationPower = 0.0
    sys_iteration_num = 800
    sys_output_name = ""
    sys_random_seed = 42
    sys_training_count = 3000
    sys_random_test = 0
    sys_gene_to_focus = 0
    sys_refinement = 0
    sys_cli_ko = []
    sys_cli_oe = []
    sys_test_GRN = ""
    test_GRN = {}
    sys_WTTP = {}

    try:
        opts, args = getopt.getopt(sys.argv[1:],
                                   "hr:t:n:p:l:o:k:e:j:m:c:f:K:O:",
                                   ["help", "input_RNAseq", "promoter_strengths",
                                    "training_count", "PerturbationPower", "gene_length",
                                    "output_name", "randomseed", "test_GRN", "random_mode",
                                    "gene_to_focus", "refinement", "ko", "oe"])
    except getopt.GetoptError:
        print('Usage: GRN_Dynamic_Simulator_parallel.py -r <input_RNAseq> '
              '-t <promoter_strengths> -l <gene_length> -o <output_name> '
              '-j <test_GRN> [-n <training_count>] [-p <PerturbationPower>] '
              '[-e <randomseed>] [-m <random_mode>] [-f <refinement>] '
              '[-K <ko_indices>] [-O <oe_indices>]')
        sys.exit(2)

    for opt, arg in opts:
        if opt in ("-h", "--help"):
            sys.exit()
        elif opt in ("-r", "--input_RNAseq"):
            sys_WTTP = load_wttp(sys_path + '/' + arg)
        elif opt in ("-f", "--refinement"):
            sys_refinement = int(arg)
        elif opt in ("-c", "--gene_to_focus"):
            sys_gene_to_focus = int(arg)
        elif opt in ("-K", "--ko"):
            sys_cli_ko = [int(x) for x in arg.split(',') if x.strip()]
        elif opt in ("-O", "--oe"):
            sys_cli_oe = [int(x) for x in arg.split(',') if x.strip()]
        elif opt in ("-e", "--randomseed"):
            sys_random_seed = int(arg)
        elif opt in ("-l", "--gene_length"):
            sys_gene_length = np.array(pd.read_csv(
                sys_path + '/' + arg, header=None, delimiter='\t'), dtype=int)[0]
        elif opt in ("-t", "--promoter_strengths"):
            sys_promoter_strengths = np.array(pd.read_csv(
                sys_path + '/' + arg, header=None, delimiter='\t'), dtype=float)
        elif opt in ("-n", "--training_count"):
            sys_training_count = int(arg)
        elif opt in ("-p", "--PerturbationPower"):
            sys_PerturbationPower = float(arg)
        elif opt in ("-m", "--random_mode"):
            sys_random_test = 1 if arg in ['True', 'TRUE', '1'] else 0
        elif opt in ("-o", "--output_name"):
            sys_output_name = arg
        elif opt in ("-j", "--test_GRN"):
            sys_test_GRN = sys_path + '/' + arg
            with open(sys_test_GRN) as f:
                for line in f:
                    parts = line.strip().split('\t')
                    if parts:
                        test_GRN[parts[0]] = parts[1:]

    random.seed(sys_random_seed)
    np.random.seed(sys_random_seed)

    TotalNumberOfGenes = len(sys_gene_length)
    sys_base_WTTP = {k: [v[0][:], v[1].copy()] for k, v in sys_WTTP.items()}
    apply_cli_perturbation(sys_WTTP, sys_cli_ko, sys_cli_oe)

    (Overexpression, Knockout, BaseMatrixCollector,
     TranscriptionPofileMax, TranscriptionPofileMin, TranscriptionPofileAve,
     indexes_of_diff_gene, indexes_of_same_gene) = build_stats(sys_WTTP, TotalNumberOfGenes, base_wttp=sys_base_WTTP)

    # NOTE: the low-fitness gene filter has been removed here so that this CLI
    # (single-condition) path matches the batch path used for the original
    # single-perturbation runs. Every diff gene, including low-fitness ones,
    # stays in the dynamics, so a CLI -K/-O perturbation always takes effect
    # (otherwise KO/OE of a filtered gene would be silently dropped).

    this_GRN = build_grn(test_GRN, indexes_of_same_gene, sys_random_test, TotalNumberOfGenes)

    # Apply refinement if requested
    if sys_refinement:
        refinement_data = read_refinement_files('./result')
        for each_refined_gene in refinement_data:
            refinement_AM = refinement_data[each_refined_gene].split(';')[1]
            refinement_LG = [int(x) for x in
                             refinement_data[each_refined_gene].split(';')[2].split('\t')[0].split(',')]
            refinement_f0_c = [float(x) for x in
                               refinement_data[each_refined_gene].split(';')[3].split('\t')]
            this_GRN_configuration = ConfigurationTo012(this_GRN.Configuration)
            for ci in range(len(this_GRN_configuration)):
                if ci % TotalNumberOfGenes == int(each_refined_gene):
                    this_GRN_configuration = (this_GRN_configuration[:ci] +
                                              refinement_AM[ci // TotalNumberOfGenes] +
                                              this_GRN_configuration[ci + 1:])
            this_GRN.SetAM(String012ToMatrix(this_GRN_configuration))
            this_GRN.LogicGates[int(each_refined_gene)] = refinement_LG
            this_GRN.f0_c[int(each_refined_gene)] = refinement_f0_c

    run_simulation(sys_WTTP, Overexpression, this_GRN,
                   indexes_of_diff_gene, sys_training_count, sys_PerturbationPower,
                   TranscriptionPofileMax, TranscriptionPofileMin,
                   sys_output_name)
