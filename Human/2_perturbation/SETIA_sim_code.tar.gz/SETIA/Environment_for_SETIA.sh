#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=32GB
#SBATCH --time=48:00:00
#SBATCH --partition=basic

conda config --add pkgs_dirs /scratch/res6024/conda_pkgs
conda env create -f EvoAlg_env.yml -p /scratch/res6024/EvoAlg