#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=10
#SBATCH --mem=32GB
#SBATCH --time=48:00:00
#SBATCH --partition=basic
#SBATCH --array=6-9

seeds=(42 123 456 789 101112 131415 161718 192021 222324 252627)
outputs=("BMMC_0" "BMMC_1" "BMMC_2" "BMMC_3" "BMMC_4" "BMMC_5" "BMMC_6" "BMMC_7" "BMMC_8" "BMMC_9")

seed=${seeds[$SLURM_ARRAY_TASK_ID]}
output=${outputs[$SLURM_ARRAY_TASK_ID]}
RELATIVE_IDX=$((SLURM_ARRAY_TASK_ID - 6))
AM_DIR="data/BMMC_init_AMs"

source $(conda info --base)/etc/profile.d/conda.sh
conda activate /scratch/res6024/EvoAlg

# ── 定向搜索：只由第一个task运行一次，生成所有AM文件 ─────────────
if [ ${RELATIVE_IDX} -eq 0 ]; then
    mkdir -p ${AM_DIR}
    python 0_Directed_Init.py \
        -r data/setia_input_linear_CPM_pseudocount.tsv \
        -c data/BMMC_TF_DNA_matrix.txt \
        -t data/BMMC_promoter_strength.txt \
        -l data/BMMC_gene_length.txt \
        -o ${AM_DIR} \
        -n 5
    touch ${AM_DIR}/done
else
    while [ ! -f ${AM_DIR}/done ]; do sleep 10; done
fi

# ── 取当前seed对应的AM（不够就循环，多了就截断）────────────────────
N_AMS=$(ls ${AM_DIR}/AM_*.txt 2>/dev/null | wc -l)
AM_IDX=$((RELATIVE_IDX % N_AMS))
AM_FILE="${AM_DIR}/AM_${AM_IDX}.txt"

# ── SETIA演化 ────────────────────────────────────────────────────
export SETIA_DEBUG_DUMP=1
python EGRN_Multi_Genalg_Combinatorial_2025.py \
    -c data/BMMC_TF_DNA_matrix.txt \
    -g data/BMMC_LG.txt \
    -r data/setia_input_linear_CPM_pseudocount.tsv \
    -b data/setia_input_linear_CPM_std_pseudocount.tsv \
    -n 3000 \
    -i 200 \
    -p 0 \
    -t data/BMMC_promoter_strength.txt \
    -l data/BMMC_gene_length.txt \
    -o "${output}" \
    -e "${seed}" \
    -f 1 \
    -k 0 \
    -d "${AM_FILE}"

conda deactivate
